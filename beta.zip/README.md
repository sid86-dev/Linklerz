# Linklerz 

<p align="center">
<img alt="" src="/static/img/linklerz_logo.png" width="150px">
</p>

Name | Endpoint | Quicklink
------------ | ------------- | -------------
Website | `/` | [here](https://lerz.herokuapp.com/)
Api | `/api` | [here](https://lerz.herokuapp.com/api/sid86_)
Admin | `/admin` | [here](https://lerz.herokuapp.com/admin_dashboard)
